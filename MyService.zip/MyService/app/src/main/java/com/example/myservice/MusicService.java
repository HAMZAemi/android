package com.example.myservice;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.IBinder;
import android.widget.Toast;
import android.R.raw;

import java.io.IOException;

public class MusicService extends Service {

    MediaPlayer player;
    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override

    public void onCreate() {
        Toast.makeText(this, "Service créé", Toast.LENGTH_LONG).show();
        player = MediaPlayer.create(this, R.raw.kouz1);
}

    @Override
    public void onDestroy() {
        Toast.makeText(this, "Service détruit", Toast.LENGTH_LONG).show();
        player.stop();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this, "Service démarré", Toast.LENGTH_LONG).show();
        player.start();
        return START_STICKY;}
}

